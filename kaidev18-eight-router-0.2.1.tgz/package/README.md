# 8Router

**AI Routing Gateway** — One Router. Multi Providers. Zero Downtime.

## Features

- 🚀 **20+ Providers** — Groq, Mistral, OpenRouter, Ollama, and more
- 🔄 **3-Tier Fallback** — Automatic failover between providers
- 💰 **Token Saver** — 20-65% cost reduction via smart routing
- 🎯 **9 Service Kinds** — Coding, Creative, Privacy, Fast, Smart, etc.
- 📊 **Dashboard** — Real-time monitoring and analytics
- 🔑 **API Keys** — Virtual key management with quotas
- 🛡️ **Guardrails** — Content filtering and rate limiting

## Quick Start

```bash
# Install globally
npm install -g 8router

# Start the server
8router

# Or run with custom config
8router --config ./my-config.yaml
```

## API Endpoints

- **API**: `http://localhost:8080/v1`
- **Dashboard**: `http://localhost:8081`
- **Hermes Proxy**: `http://localhost:8083/v1`

## Configuration

Create `8router.yaml` in your project root:

```yaml
providers:
  - id: groq
    apiKey: your-groq-key
    models: ["llama-3.1-70b-versatile"]
  
  - id: mistral
    apiKey: your-mistral-key
    models: ["mistral-large-latest"]

routing:
  strategy: fallback
  timeout: 30000
```

## CLI Tools

8Router works with:

- **Hermes Agent** — Nous Research AI agent
- **Claude Code** — Anthropic's CLI
- **OpenAI Codex** — OpenAI's coding CLI
- **Cursor** — AI-first code editor
- **Cline** — VS Code AI assistant

## Dashboard

Access the dashboard at `http://localhost:8081` to:

- Monitor request volume and latency
- Track token usage and costs
- Test providers in the Playground
- Manage API keys and quotas
- View system health and logs

## License

MIT © 8Agents
